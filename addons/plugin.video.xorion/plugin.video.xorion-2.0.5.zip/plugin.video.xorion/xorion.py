
import sys
import urlresolver
import urllib,urllib2,cookielib
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import json
import StringIO
import urlresolver

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)



ben = 'http://xmoxmo-001-site1.btempurl.com/XorService.svc/xorvod/ana/xorionxor?url=xor'




class track():
    def __init__(self, length, title, path):
        self.length = length
        self.title = title
        self.path = path

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def parseM3U(infile):
    inf = get_url(infile)

   
    buf=StringIO.StringIO(inf)
    line = buf.readline()
    if not line.startswith('#EXTM3U'):
       return

   
    playlist=[]
    song=track(None,None,None)

    for line in buf:
        line=line.strip()
        if line.startswith('#EXTINF:'):
           
            length,title=line.split('#EXTINF:')[1].split(',',1)
            song=track(length,title,None)
        elif (len(line) != 0):
           
            song.path=line
            playlist.append(song)

            
            song=track(None,None,None)

    buf.close()

    return playlist

def m3uAl(url):
    
    playlist = parseM3U(url)
    for track in playlist:
        addDir('[COLOR orange][B]'+ track.title +'[/B][/COLOR]',track.path,3,"")
        #print (track.title, track.path)





def HadiBakalim():
        xorion(ben)
def xorion(url):
    f = urllib2.urlopen(url)
    js = json.load(f)
   
   
    for rs in js['Linklerim']:
            baslik=rs['Baslik'].encode('utf-8')
            resim=rs['Resim'].encode('utf-8')
            bak=rs['StreamUrl']
            linkim = rs['PlayList']
            #siraNo=str(rs['idNo'])
            koruma=rs['Koruma']
           

            if not bak: 
                url= str(linkim)
                if "m3u" in url:
                
                 addDir('[COLOR orange][B]'+ baslik +'[/B][/COLOR]',url,0,resim)    
                else:
                 addDir('[COLOR orange][B]'+ baslik +'[/B][/COLOR]',url,2,resim)
               
            else:
                url=str(bak)
                #print 'bbbstream :' + url
                addDir('[COLOR white][B]' + baslik + '[/B][/COLOR]',url,3,resim)




def oynat(url,baslik):       
        playList.clear()
        url = str(url).encode('utf-8', 'ignore')
        
        
        if '.ts' in url:
                url= url
        
        elif 'rtmp:'  in url:
                url= url
        elif 'rtsp:'  in url:
                url= url                                
        elif  '.ts:' in url:
                url= url
        elif '.m3u8' in url:
                url= url
        elif '.mp4' in url:
                url= url		
        else:		
                url=urlresolver.resolve(url)
        if url:
                addLink(baslik,url,'')
                
                listitem = xbmcgui.ListItem(baslik, iconImage="DefaultFolder.png", thumbnailImage='')
                listitem.setInfo('video', {'name': baslik } )
                playList.add(str(url),listitem=listitem)
                xbmcPlayer.play(playList)
        else:
                showMessage("[COLOR blue][B]Xor[/B][/COLOR]","[COLOR blue][B]Link bulunamadi ya da acilamiyor[/B][/COLOR]")


				
				
				



		
def get_url(url):
        req = urllib2.Request(url)
        req.add_header('Referer', url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        #req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        #req.add_header('Cache-Control', 'no-transform')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
def showMessage(heading='Xor', message = '', times = 3000, pics = ''):
		try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
		except Exception, e:
			xbmc.log( '[%s]: showMessage: exec failed [%s]' % ('', e), 1 )
def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=str(url),listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]               
        return param
params=get_params()
url=None
name=None
mode=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
       
        HadiBakalim()
elif mode==0:
       
        m3uAl(url)       
elif mode==2:
       
        xorion(url)
        
elif mode==3:
       
        oynat(url,name)

        

xbmcplugin.endOfDirectory(int(sys.argv[1]))

