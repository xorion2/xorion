

#--XorioN
#-------XorioN
# -----------XorioN 
#-----------------XorioN
#----------------------XorioN
#---------------------------XorioN 03.05.2017 for WETEK users
#----------------------XorioN
#-----------------XorioN
# -----------XorioN 
#-------XorioN
#--XorioN


import sys,platform
import urlresolver
import urllib,urllib2,cookielib
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import json
from urlparse import parse_qsl
from urllib import urlencode

xbmcPlayer = xbmc.Player()

settings = xbmcaddon.Addon(id='plugin.video.xorion')

_url = sys.argv[0]

_handle = int(sys.argv[1])

ben = 'http://xmoxmo-001-site1.btempurl.com/XorService.svc/xorvod/ana/xorion/' + str(settings.getSetting( "user" )) + '/' +  str(settings.getSetting( "pass" )) + '/' + str(settings.getSetting( "ext" )) + '/XOR?url=xor'

adultx = str(settings.getSetting( "adult" ))




def HadiBakalim():
       	
        xorion(ben)


def xorion(url):
   
    req = urllib2.Request(url)
    req.add_header('User-Agent', str(platform.uname()))
    f = urllib2.urlopen(req)
    js = json.load(f)
   
    
   
    for rs in js['Linklerim']:
            baslik=rs['Baslik'].encode('utf-8')
            resim=rs['Resim'].encode('utf-8')
            bak=rs['StreamUrl']
            linkim = rs['PlayList']
            
            koruma=rs['Koruma']

            list_item = xbmcgui.ListItem(label=baslik)

            list_item.setArt({'thumb': resim,
                          'icon': resim,
                          'fanart': resim})

            

            list_item.setInfo('video', {'title':baslik , 'genre': baslik})
           

            if not bak: 
            

				
                if koruma == "True" and adultx == "false" :
				    
					continue
				
                
                url= str(linkim) 
                url = get_url(action='listing', category=url)
                is_folder = True
      			
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
               
            else:
                url=str(bak)

                list_item = xbmcgui.ListItem(label='[COLOR orange][B]' +  baslik + '[/B][/COLOR]')

                list_item.setProperty('IsPlayable', 'true')
      
                url = get_url(action='play', video=url)
              
                is_folder = False
      
                xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    #xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    
    xbmcplugin.endOfDirectory(_handle)


def oynat(url):       
       
		
        url = str(url).encode('utf-8', 'ignore')
        
        NatUrl = url

        url = urlresolver.resolve(url)

        if not url:
            url = NatUrl
        
       

        if url:
                
                play_item = xbmcgui.ListItem(path=url)
   
                xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)

        else:
                showMessage("[COLOR blue][B]XorioN[/B][/COLOR]","[COLOR blue][B]Link bulunamadi ya da acilamiyor..[/B][/COLOR]")



				
def get_url(**kwargs):
    
    return '{0}?{1}'.format(_url, urlencode(kwargs))


		

def showMessage(heading='Xor', message = '', times = 3000, pics = ''):
		try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
		except Exception, e:
			xbmc.log( '[%s]: showMessage: exec failed [%s]' % ('', e), 1 )



def router(paramstring):
   
    params = dict(parse_qsl(paramstring))
  
    if params:
        if params['action'] == 'listing':
           
            xorion(params['category'])
        elif params['action'] == 'play':
            
            oynat(params['video'])

        
        else:
          
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
      
        HadiBakalim()


if __name__ == '__main__':
    
    router(sys.argv[2][1:])


