

#--XorioN
#-------XorioN
# -----------XorioN
#-----------------XorioN
#----------------------XorioN
#---------------------------XorVod 23.04.2018 for WETEK users
#----------------------XorioN
#-----------------XorioN
# -----------XorioN
#-------XorioN
#--XorioN


import sys
import platform
import urlresolver
import urllib
import urllib2

import cookielib
import re
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
import json
from urlparse import parse_qsl
from urllib import urlencode

xbmcPlayer = xbmc.Player()

settings = xbmcaddon.Addon(id='plugin.video.xorion')

_url = sys.argv[0]

_handle = int(sys.argv[1])


adultx = str(settings.getSetting("adult"))


def tokenAl():
    tokenParams = {'grant_type': 'password',
                   'username':  str(settings.getSetting("user")), 'password': str(settings.getSetting("pass"))}
    url = 'http://xmoxmo-001-site1.btempurl.com/token'
    data = urllib.urlencode(tokenParams)
    req = urllib2.Request(url=url, data=data)
    content = urllib2.urlopen(req).read()
    datam = json.loads(content)
    print content
    settings.setSetting(id="token", value='Bearer ' +
                        str(datam['access_token']))
    


def HadiBakalim():
   
    tokenAl()
    ben = 'http://xmoxmo-001-site1.btempurl.com/api/linkler?ad=xorvod&url=xor'
    xorion(ben)


def xorion(url):

    req = urllib2.Request(url)
    req.add_header('User-Agent', str(platform.uname()))
    req.add_header('Content-Type', 'application/json')
    req.add_header('Authorization', str(settings.getSetting("token")))
    f = urllib2.urlopen(req)
    js = json.load(f)
    
    for rs in js['Linklerim']:
       
        
        if not rs['Title']:
            continue

        baslik = rs['Title'].encode('utf-8')

        resim = ''
        
        if rs['Image']:
            resim = rs['Image'].encode('utf-8') 
        
        aciklama = ''
       
        if rs['Description']:
       
           aciklama = rs['Description'].encode('ascii', 'ignore')
           aciklama = re.sub('<[^<]+?>', '', aciklama) 
       
       
      
        bak = rs['Streamurl']
        linkim = rs['Playlist']
        kind = rs['Kind']
        koruma = rs['Protectedx']
       

        

        list_item = xbmcgui.ListItem(label=baslik)

        list_item.setArt({'thumb': resim,
                          'icon': resim, 'poster': resim,
                          'fanart': resim})

        list_item.setInfo(
            'video', {'title': baslik, 'plot': aciklama, 'genre': baslik, 'thumb': resim})

        if not bak:

            if koruma == "True" and adultx == "false":

                continue

            url = str(linkim)

            is_folder = True

            if kind == 'search':
                if adultx == "false" and "ad=vkara" in url:
                    continue

                url = get_url(action='arama', category=url)

            else:
                url = get_url(action='listing', category=url)

            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

        else:
            url = str(bak)

            list_item = xbmcgui.ListItem(
                label='[COLOR orange][B]' + baslik + '[/B][/COLOR]')

            list_item.setProperty('IsPlayable', 'true')

            list_item.setArt({'thumb': resim,
                              'icon': resim, 'poster': resim,
                              'fanart': resim})

            list_item.setInfo(
                'video', {'title': baslik, 'plot': aciklama, 'genre': baslik, 'thumb': resim})

            url = get_url(action='play', video=url)

            is_folder = False

            xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)

    #xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)

    xbmcplugin.endOfDirectory(_handle)


def oynat(url):

    url = str(url).encode('utf-8', 'ignore')

    NatUrl = url

    url = urlresolver.resolve(url)

    if not url:
        url = NatUrl

    if url:

        play_item = xbmcgui.ListItem(path=url)

        xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)

    else:
        showMessage("[COLOR blue][B]XorioN[/B][/COLOR]",
                    "[COLOR blue][B]Link bulunamadi ya da acilamiyor..[/B][/COLOR]")


def get_url(**kwargs):

    return '{0}?{1}'.format(_url, urlencode(kwargs))


def showMessage(heading='Xor', message='', times=3000, pics=''):
    try:
        xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (
            heading, message, times, pics))
    except Exception, e:
        xbmc.log('[%s]: showMessage: exec failed [%s]' % ('', e), 1)


def router(paramstring):

    params = dict(parse_qsl(paramstring))

    if params:
        if params['action'] == 'listing':

            xorion(params['category'])

        elif params['action'] == 'arama':
            searchterm = ""

            keyboard = xbmc.Keyboard('', "Video Ara", False)
            keyboard.doModal()
            if (keyboard.isConfirmed()):
                searchterm = keyboard.getText()
                arayalim = str(urllib.quote(searchterm))

                url = params['category'] + '&q=' + arayalim

                xorion(url)

        elif params['action'] == 'play':

            oynat(params['video'])
        else:

            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:

        HadiBakalim()


if __name__ == '__main__':

    router(sys.argv[2][1:])
